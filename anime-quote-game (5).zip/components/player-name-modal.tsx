"use client"

import type React from "react"
import { useState } from "react"

interface PlayerNameModalProps {
  isOpen: boolean
  onSubmit: (name: string) => void
  onClose: () => void
  finalScore: number
  correctAnswers: number
  wrongAnswers: number
}

export default function PlayerNameModal({
  isOpen,
  onSubmit,
  onClose,
  finalScore,
  correctAnswers,
  wrongAnswers,
}: PlayerNameModalProps) {
  const [playerName, setPlayerName] = useState("")
  const [saving, setSaving] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (playerName.trim() && !saving) {
      setSaving(true)
      try {
        await onSubmit(playerName.trim())
        setPlayerName("")
      } catch (error) {
        console.error("Failed to save score:", error)
      } finally {
        setSaving(false)
      }
    }
  }

  const handleSkip = () => {
    setPlayerName("")
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h3>🎉 Game Complete! 🎉</h3>
        <div className="score-summary">
          <p>
            <strong>Final Score: {finalScore}</strong>
          </p>
          <p>
            Correct: {correctAnswers} | Wrong: {wrongAnswers}
          </p>
        </div>

        <p>Save your score to the local leaderboard!</p>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            placeholder="Enter your name..."
            maxLength={20}
            autoFocus
            disabled={saving}
          />
          <div className="modal-buttons">
            <button type="submit" disabled={!playerName.trim() || saving}>
              {saving ? "💾 Saving..." : "💾 Save Score"}
            </button>
            <button type="button" onClick={handleSkip} disabled={saving}>
              ⏭️ Skip
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
