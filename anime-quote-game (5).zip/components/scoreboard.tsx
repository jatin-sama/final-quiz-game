"use client"

import { useState, useEffect } from "react"
import { getTopLocalScores, type ScoreEntry } from "@/lib/local-storage"

interface ScoreboardProps {
  isOpen: boolean
  onClose: () => void
}

export default function Scoreboard({ isOpen, onClose }: ScoreboardProps) {
  const [scores, setScores] = useState<ScoreEntry[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (isOpen) {
      fetchScores()
    }
  }, [isOpen])

  const fetchScores = () => {
    setLoading(true)
    try {
      const topScores = getTopLocalScores(10)
      setScores(topScores)
    } catch (error) {
      console.error("Failed to fetch scores:", error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleDateString()
    } catch {
      return ""
    }
  }

  if (!isOpen) return null

  return (
    <div className="scoreboard-overlay">
      <div className="scoreboard-modal">
        <div className="scoreboard-header">
          <h2>🏆 Top Players 🏆</h2>
          <button className="close-btn" onClick={onClose}>
            ✕
          </button>
        </div>

        <div className="scoreboard-content">
          {loading ? (
            <div className="loading">
              <p>Loading scores...</p>
              <div className="loading-spinner">🎮</div>
            </div>
          ) : scores.length === 0 ? (
            <div className="no-scores">
              <p>No scores yet! Be the first to play!</p>
              <p>🎯 Complete a game to appear on the leaderboard!</p>
            </div>
          ) : (
            <div className="scores-list">
              {scores.map((score, index) => (
                <div key={score.id} className={`score-item ${index < 3 ? "top-three" : ""}`}>
                  <div className="rank">
                    {index === 0 && "🥇"}
                    {index === 1 && "🥈"}
                    {index === 2 && "🥉"}
                    {index > 2 && `#${index + 1}`}
                  </div>
                  <div className="player-info">
                    <div className="player-name">{score.playerName}</div>
                    <div className="player-stats">
                      {score.correctAnswers}✅ / {score.wrongAnswers}❌
                    </div>
                    <div className="player-date">{formatDate(score.date)}</div>
                  </div>
                  <div className="score-value">{score.score}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <button className="refresh-btn" onClick={fetchScores} disabled={loading}>
          {loading ? "🔄 Loading..." : "🔄 Refresh"}
        </button>
      </div>
    </div>
  )
}
