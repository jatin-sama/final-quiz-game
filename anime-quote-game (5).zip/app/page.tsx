"use client"

import { useState, useEffect } from "react"
import Scoreboard from "@/components/scoreboard"
import PlayerNameModal from "@/components/player-name-modal"
import { saveScoreToLocal } from "@/lib/local-storage"

const animeList = [
  "Naruto",
  "One Piece",
  "Attack on Titan",
  "Death Note",
  "Fullmetal Alchemist: Brotherhood",
  "Bleach",
  "Dragon Ball Z",
  "Demon Slayer",
  "Jujutsu Kaisen",
  "Tokyo Ghoul",
  "My Hero Academia",
  "Code Geass",
  "Mob Psycho 100",
  "Steins;Gate",
  "Hunter x Hunter",
  "Sword Art Online",
  "Black Clover",
  "Fairy Tail",
  "Erased",
  "Re:Zero",
  "Noragami",
  "Violet Evergarden",
  "The Promised Neverland",
  "Clannad",
  "Blue Lock",
  "Chainsaw Man",
  "Horimiya",
  "Your Lie in April",
  "Anohana",
  "86",
  "Bungou Stray Dogs",
  "Psycho-Pass",
  "Akame ga Kill",
  "The Rising of the Shield Hero",
  "Dr. Stone",
  "Toradora!",
  "Parasyte: The Maxim",
  "Haikyuu!!",
  "March Comes in Like a Lion",
  "Yuri on Ice",
  "Kaguya-sama: Love is War",
  "Owari no Seraph",
  "The Devil is a Part-Timer!",
  "Zankyou no Terror",
  "Devilman Crybaby",
  "Made in Abyss",
  "Fate/Stay Night",
  "Terror in Resonance",
  "Hyouka"
];

// Mock anime quotes data
const mockQuotes = [
  {
    anime: "Naruto",
    character: "Naruto Uzumaki",
    quote: "I'm not gonna run away, I never go back on my word! That's my nindo: my ninja way!"
  },
  {
    anime: "One Piece",
    character: "Monkey D. Luffy",
    quote: "I'm gonna be King of the Pirates!"
  },
  {
    anime: "Attack on Titan",
    character: "Eren Yeager",
    quote: "If you win, you live. If you lose, you die. If you don't fight, you can't win!"
  },
  {
    anime: "Death Note",
    character: "Light Yagami",
    quote: "I am justice! I protect the innocent and those who fear evil."
  },
  {
    anime: "Fullmetal Alchemist: Brotherhood",
    character: "Edward Elric",
    quote: "A lesson without pain is meaningless."
  },
  {
    anime: "Bleach",
    character: "Ichigo Kurosaki",
    quote: "I'm not fighting because I want to win, I'm fighting because I have to win!"
  },
  {
    anime: "Dragon Ball Z",
    character: "Goku",
    quote: "I am the hope of the universe!"
  },
  {
    anime: "Demon Slayer",
    character: "Tanjiro Kamado",
    quote: "The bond between Nezuko and me can’t be severed by anyone!"
  },
  {
    anime: "Jujutsu Kaisen",
    character: "Gojo Satoru",
    quote: "Throughout heaven and earth, I alone am the honored one."
  },
  {
    anime: "Tokyo Ghoul",
    character: "Kaneki Ken",
    quote: "It's not the world that’s messed up; it’s those of us in it."
  },
  {
    anime: "My Hero Academia",
    character: "All Might",
    quote: "It’s fine now. Why? Because I am here!"
  },
  {
    anime: "Code Geass",
    character: "Lelouch Lamperouge",
    quote: "If the king doesn't lead, how can he expect his subordinates to follow?"
  },
  {
    anime: "Mob Psycho 100",
    character: "Shigeo Kageyama",
    quote: "If everyone is not special, maybe you can be what you want to be."
  },
  {
    anime: "Steins;Gate",
    character: "Okabe Rintarou",
    quote: "Remember, I am mad scientist. It's so cool! Sonuvabitch."
  },
  {
    anime: "Hunter x Hunter",
    character: "Killua Zoldyck",
    quote: "I’m so tired of killing. I just want to be a kid."
  },
  {
    anime: "Sword Art Online",
    character: "Kirito",
    quote: "I'd rather trust and regret than doubt and regret."
  },
  {
    anime: "Black Clover",
    character: "Asta",
    quote: "I’ll become the Wizard King!"
  },
  {
    anime: "Fairy Tail",
    character: "Natsu Dragneel",
    quote: "We're not your puppets! Don't underestimate us!"
  },
  {
    anime: "Erased",
    character: "Satoru Fujinuma",
    quote: "I’m scared to get hurt again. But I want to change the future."
  },
  {
    anime: "Re:Zero",
    character: "Subaru Natsuki",
    quote: "I’m not strong. I just have something I want to protect."
  },
  {
    anime: "Noragami",
    character: "Yato",
    quote: "A wish? I’m a god, you know. I’ll make it come true."
  },
  {
    anime: "Violet Evergarden",
    character: "Violet Evergarden",
    quote: "I want to know what 'I love you' means."
  },
  {
    anime: "The Promised Neverland",
    character: "Emma",
    quote: "No matter what happens, we'll always be together."
  },
  {
    anime: "Clannad",
    character: "Tomoya Okazaki",
    quote: "You shouldn't be afraid to cry. It's okay to cry."
  },
  {
    anime: "Blue Lock",
    character: "Isagi Yoichi",
    quote: "This is the formula to awaken my ego."
  },
  {
    anime: "Chainsaw Man",
    character: "Denji",
    quote: "All I want is a normal life. With toast, jam, and a girl."
  },
  {
    anime: "Horimiya",
    character: "Izumi Miyamura",
    quote: "Even if you can't see something, it doesn't mean it isn't there."
  },
  {
    anime: "Your Lie in April",
    character: "Kousei Arima",
    quote: "Maybe there’s only a dark road up ahead. But you still have to believe and keep going."
  },
  {
    anime: "Anohana",
    character: "Jinta Yadomi",
    quote: "We found it... Our peace. Together."
  },
  {
    anime: "86",
    character: "Shinei Nouzen",
    quote: "We’re not tools, we’re not numbers. We’re people."
  },
  {
    anime: "Bungou Stray Dogs",
    character: "Dazai Osamu",
    quote: "A lesson without pain is meaningless—that’s what they say."
  },
  {
    anime: "Psycho-Pass",
    character: "Shinya Kogami",
    quote: "The law doesn't protect people. People protect the law."
  },
  {
    anime: "Akame ga Kill",
    character: "Akame",
    quote: "Your life belongs to you and no one else."
  },
  {
    anime: "The Rising of the Shield Hero",
    character: "Naofumi Iwatani",
    quote: "I’ll survive no matter what. That’s the only thing I’ve decided."
  },
  {
    anime: "Dr. Stone",
    character: "Senku Ishigami",
    quote: "I’m going to save every single person with the power of science!"
  },
  {
    anime: "Toradora!",
    character: "Taiga Aisaka",
    quote: "Even if I'm scared... I have to try."
  },
  {
    anime: "Parasyte: The Maxim",
    character: "Shinichi Izumi",
    quote: "Humans aren't as weak as you think they are."
  },
  {
    anime: "Haikyuu!!",
    character: "Shoyo Hinata",
    quote: "The future belongs to those who believe in themselves!"
  },
  {
    anime: "March Comes in Like a Lion",
    character: "Rei Kiriyama",
    quote: "It's okay to be weak. Just don't stay that way forever."
  },
  {
    anime: "Yuri on Ice",
    character: "Yuri Katsuki",
    quote: "I’m going to skate the way I want to from now on."
  },
  {
    anime: "Kaguya-sama: Love is War",
    character: "Miyuki Shirogane",
    quote: "Love is war. The one who confesses loses."
  },
  {
    anime: "Owari no Seraph",
    character: "Yuuichirou Hyakuya",
    quote: "I don't care what I have to do. I'll protect my family!"
  },
  {
    anime: "The Devil is a Part-Timer!",
    character: "Sadao Maou",
    quote: "I swear I will rise again. Even if I work part-time!"
  },
  {
    anime: "Zankyou no Terror",
    character: "Nine",
    quote: "We are not just terrorists. We are a warning."
  },
  {
    anime: "Devilman Crybaby",
    character: "Akira Fudo",
    quote: "Even if I turn into a demon, I won’t kill you."
  },
  {
    anime: "Made in Abyss",
    character: "Riko",
    quote: "I'm going to find my mom, no matter how deep I have to go!"
  },
  {
    anime: "Fate/Stay Night",
    character: "Shirou Emiya",
    quote: "I want to become a hero of justice!"
  },
  {
    anime: "Terror in Resonance",
    character: "Twelve",
    quote: "We wanted someone to hear us. That’s all."
  },
  {
    anime: "Hyouka",
    character: "Houtarou Oreki",
    quote: "If I don't have to do it, I won't. If I have to do it, I'll make it quick."
  }
];

export default function AnimeQuoteGame() {
  const [quote, setQuote] = useState("Loading...")
  const [character, setCharacter] = useState("")
  const [options, setOptions] = useState([])
  const [result, setResult] = useState("")
  const [correctAnswer, setCorrectAnswer] = useState("")
  const [scoreCorrect, setScoreCorrect] = useState(0)
  const [scoreWrong, setScoreWrong] = useState(0)
  const [showNext, setShowNext] = useState(false)
  const [loading, setLoading] = useState(false)
  const [backgroundStickers, setBackgroundStickers] = useState([])
  const [showScoreboard, setShowScoreboard] = useState(false)
  const [showNameModal, setShowNameModal] = useState(false)
  const [gameEnded, setGameEnded] = useState(false)
  const [totalQuestions, setTotalQuestions] = useState(0)

  function getRandomItem(arr: string[]) {
    return arr[Math.floor(Math.random() * arr.length)]
  }

  function generateOptions(correct: string) {
    const filtered = animeList.filter((anime) => anime !== correct)
    const shuffled = filtered.sort(() => Math.random() - 0.5)
    const fakeOptions = shuffled.slice(0, 3)
    const allOptions = [...fakeOptions, correct]
    return allOptions.sort(() => Math.random() - 0.5)
  }

  function generateBackgroundStickers() {
    const stickers = []
    const stickerCount = 8 // Number of background stickers

    for (let i = 0; i < stickerCount; i++) {
      stickers.push({
        id: i,
        src: `/placeholder.svg?height=60&width=60&query=cute anime chibi character ${i + 1}`,
        top: Math.random() * 80 + 10, // 10% to 90% from top
        left: Math.random() * 80 + 10, // 10% to 90% from left
        rotation: Math.random() * 360, // Random rotation
        scale: Math.random() * 0.4 + 0.6, // Scale between 0.6 and 1.0
        opacity: Math.random() * 0.3 + 0.1, // Opacity between 0.1 and 0.4
      })
    }
    setBackgroundStickers(stickers)
  }

  async function fetchQuote() {
    setResult("")
    setOptions([])
    setQuote("Loading...")
    setCharacter("")
    setShowNext(false)
    setLoading(true)

    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Get random quote from mock data
      const randomIndex = Math.floor(Math.random() * mockQuotes.length)
      const data = mockQuotes[randomIndex]

      setCorrectAnswer(data.anime)
      setQuote(`"${data.quote}"`)

      const newOptions = generateOptions(data.anime)
      setOptions(newOptions)

      // Generate new background stickers for each quote
      generateBackgroundStickers()
    } catch (err) {
      setQuote("Failed to load quote 💔")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  function checkAnswer(selected: string) {
    if (selected === correctAnswer) {
      setResult("✅ Correct!")
      setScoreCorrect((prev) => prev + 1)
    } else {
      setResult(`❌ Wrong! It was ${correctAnswer}`)
      setScoreWrong((prev) => prev + 1)
    }
    setTotalQuestions((prev) => prev + 1)
    setShowNext(true)

    // Check if game should end (after 10 questions)
    if (totalQuestions + 1 >= 10) {
      setGameEnded(true)
      setTimeout(() => {
        setShowNameModal(true)
      }, 2000) // Show modal after 2 seconds to let user see final result
    }
  }

  const calculateScore = () => {
    return scoreCorrect * 10 - scoreWrong * 2
  }

  const handleSaveScore = async (playerName: string) => {
    try {
      saveScoreToLocal({
        playerName,
        score: calculateScore(),
        correctAnswers: scoreCorrect,
        wrongAnswers: scoreWrong,
      })
      setShowNameModal(false)
      setShowScoreboard(true)
    } catch (error) {
      console.error("Failed to save score:", error)
      alert("Failed to save score. Please try again.")
    }
  }

  const resetGame = () => {
    setScoreCorrect(0)
    setScoreWrong(0)
    setTotalQuestions(0)
    setGameEnded(false)
    setResult("")
    setShowNameModal(false)
    fetchQuote()
  }

  useEffect(() => {
    fetchQuote()
  }, [])

  return (
    <div className="game-container">
      {/* Background Stickers */}
      <div className="background-stickers">
        {backgroundStickers.map((sticker) => (
          <img
            key={sticker.id}
            src={sticker.src || "/placeholder.svg"}
            alt=""
            className="background-sticker"
            style={{
              position: "absolute",
              top: `${sticker.top}%`,
              left: `${sticker.left}%`,
              transform: `rotate(${sticker.rotation}deg) scale(${sticker.scale})`,
              opacity: sticker.opacity,
              zIndex: -1,
              pointerEvents: "none",
              width: "60px",
              height: "60px",
            }}
            crossOrigin="anonymous"
          />
        ))}
      </div>

      <h1>🎌 Guess the Anime by Quote 🎮</h1>

      {/* Scoreboard and Game Controls */}
      <div className="game-controls">
        <button className="scoreboard-btn" onClick={() => setShowScoreboard(true)}>
          🏆 Leaderboard
        </button>
        {gameEnded && (
          <button className="reset-btn" onClick={resetGame}>
            🔄 New Game
          </button>
        )}
      </div>

      {/* Scoreboard */}
      <div id="scoreboard">
        ✅ Correct: <span id="score-correct">{scoreCorrect}</span> | ❌ Wrong:{" "}
        <span id="score-wrong">{scoreWrong}</span> | 🎯 Score: <span className="total-score">{calculateScore()}</span>
        <br />
        <small>Question {totalQuestions}/10</small>
      </div>

      {!gameEnded ? (
        <>
          {/* Quote Box */}
          <div id="quote-box">
            <p id="quote">{quote}</p>
          </div>

          {/* Options */}
          <div id="options">
            {options.map((option, index) => (
              <button key={index} onClick={() => checkAnswer(option)} disabled={showNext || loading}>
                {option}
              </button>
            ))}
          </div>

          {/* Result and Next */}
          <p id="result">{result}</p>
          {showNext && totalQuestions < 10 && (
            <button id="nextBtn" onClick={fetchQuote}>
              ✨ Next Quote ✨
            </button>
          )}
        </>
      ) : (
        <div className="game-over">
          <h2>🎉 Game Complete! 🎉</h2>
          <div className="final-score">
            <p>
              Final Score: <strong>{calculateScore()}</strong>
            </p>
            <p>
              Correct: {scoreCorrect} | Wrong: {scoreWrong}
            </p>
            <p className="save-prompt">Your score will be saved to the local leaderboard!</p>
          </div>
        </div>
      )}

      {/* Copyright Footer */}
      <footer className="copyright-footer">
        <p>
          © 2025 Jamtin Sama | Contact: <a href="mailto:xzenpai99@gmail.com">xzenpai99@gmail.com</a>
        </p>
      </footer>

      {/* Modals */}
      <PlayerNameModal
        isOpen={showNameModal}
        onSubmit={handleSaveScore}
        onClose={() => setShowNameModal(false)}
        finalScore={calculateScore()}
        correctAnswers={scoreCorrect}
        wrongAnswers={scoreWrong}
      />
      <Scoreboard isOpen={showScoreboard} onClose={() => setShowScoreboard(false)} />
    </div>
  )
}
