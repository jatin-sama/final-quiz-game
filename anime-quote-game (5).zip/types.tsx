export interface QuoteData {
  anime: string
  character: string
  quote: string
}

export interface ScoreEntry {
  id: string
  playerName: string
  score: number
  correctAnswers: number
  wrongAnswers: number
  date: string
}
