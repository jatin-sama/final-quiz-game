import type { ScoreEntry } from "@/types"

const SCORES_KEY = "anime-quote-scores"

export function saveScoreToLocal(scoreData: Omit<ScoreEntry, "id" | "date">): string {
  try {
    const scores = getLocalScores()
    const newScore: ScoreEntry = {
      ...scoreData,
      id: Date.now().toString(),
      date: new Date().toISOString(),
    }

    scores.push(newScore)

    // Sort by score (descending) and keep only top 50
    scores.sort((a, b) => b.score - a.score)
    const topScores = scores.slice(0, 50)

    localStorage.setItem(SCORES_KEY, JSON.stringify(topScores))
    return newScore.id
  } catch (error) {
    console.error("Error saving score to local storage:", error)
    throw error
  }
}

export function getLocalScores(): ScoreEntry[] {
  try {
    const scores = localStorage.getItem(SCORES_KEY)
    return scores ? JSON.parse(scores) : []
  } catch (error) {
    console.error("Error getting scores from local storage:", error)
    return []
  }
}

export function getTopLocalScores(limit = 10): ScoreEntry[] {
  const scores = getLocalScores()
  return scores.slice(0, limit)
}

export function clearLocalScores(): void {
  try {
    localStorage.removeItem(SCORES_KEY)
  } catch (error) {
    console.error("Error clearing local scores:", error)
  }
}
