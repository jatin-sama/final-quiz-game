import { initializeApp, getApps, getApp } from "firebase/app"
import { getFirestore } from "firebase/firestore"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAfhROThdUYZz0-qQbAG1OqMy-w85WD6E4",
  authDomain: "score-of-quiz.firebaseapp.com",
  databaseURL: "https://score-of-quiz-default-rtdb.firebaseio.com",
  projectId: "score-of-quiz",
  storageBucket: "score-of-quiz.firebasestorage.app",
  messagingSenderId: "454786226244",
  appId: "1:454786226244:web:9f42b3898a5c4148ef4411",
  measurementId: "G-632HRQJMWN",
}

// Initialize Firebase app
let app
try {
  app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp()
} catch (error) {
  console.error("Error initializing Firebase app:", error)
  app = null
}

// Initialize Firestore with better error handling
let db = null
let firestoreInitialized = false

const initializeFirestore = () => {
  if (!app) {
    console.error("Firebase app not initialized")
    return null
  }

  try {
    if (!firestoreInitialized) {
      db = getFirestore(app)
      firestoreInitialized = true
      console.log("Firestore initialized successfully")
    }
    return db
  } catch (error) {
    console.error("Error initializing Firestore:", error)
    return null
  }
}

// Get Firestore instance
export const getDB = () => {
  if (!db && !firestoreInitialized) {
    return initializeFirestore()
  }
  return db
}

// Check if Firebase is available
export const isFirebaseAvailable = () => {
  return app !== null && getDB() !== null
}

// Initialize Analytics
export const initializeAnalytics = async () => {
  if (typeof window !== "undefined" && app) {
    try {
      const { getAnalytics } = await import("firebase/analytics")
      const analytics = getAnalytics(app)
      console.log("Firebase Analytics initialized successfully")
      return analytics
    } catch (error) {
      console.log("Analytics not available:", error)
      return null
    }
  }
  return null
}

// Export the app for other uses
export { app }
