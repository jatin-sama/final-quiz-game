import { getDB, isFirebaseAvailable } from "./firebase"
import { collection, addDoc, getDocs, query, orderBy, limit, serverTimestamp } from "firebase/firestore"

export interface ScoreEntry {
  id?: string
  playerName: string
  score: number
  correctAnswers: number
  wrongAnswers: number
  timestamp: any
}

export async function saveScore(scoreData: Omit<ScoreEntry, "id" | "timestamp">) {
  const db = getDB()

  if (!isFirebaseAvailable() || !db) {
    console.error("Firebase/Firestore is not available")
    throw new Error("Database not available")
  }

  try {
    const docRef = await addDoc(collection(db, "scores"), {
      ...scoreData,
      timestamp: serverTimestamp(),
    })
    console.log("Score saved successfully with ID:", docRef.id)
    return docRef.id
  } catch (error) {
    console.error("Error saving score:", error)
    throw error
  }
}

export async function getTopScores(limitCount = 10): Promise<ScoreEntry[]> {
  const db = getDB()

  if (!isFirebaseAvailable() || !db) {
    console.error("Firebase/Firestore is not available")
    return []
  }

  try {
    const q = query(collection(db, "scores"), orderBy("score", "desc"), orderBy("timestamp", "desc"), limit(limitCount))
    const querySnapshot = await getDocs(q)
    const scores = querySnapshot.docs.map(
      (doc) =>
        ({
          id: doc.id,
          ...doc.data(),
        }) as ScoreEntry,
    )
    console.log("Fetched scores:", scores.length)
    return scores
  } catch (error) {
    console.error("Error fetching scores:", error)
    return []
  }
}

// Check if Firestore is available
export function isFirestoreAvailable(): boolean {
  return isFirebaseAvailable()
}
